<?php
	include("templates/header.php");
	include("templates/logo.php");
	include("templates/about-us.php");
	include("templates/advantages.php");
	include("templates/feedback.php");
	include("templates/footer.php");
?>