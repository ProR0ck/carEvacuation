<?php
	include("templates/header.php");
	include("templates/load-prices.php");
	include("templates/map.php");
	include("templates/map-script.php");
	include("templates/advantages.php");
	include("templates/footer.php");
?>