<?php
	include("templates/header.php");
	include("templates/contacts.php");
	include("templates/feedback.php");
	include("templates/footer.php");
?>