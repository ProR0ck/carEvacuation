<?php
	include("templates/header.php");
	include("templates/auth.php");
	include("templates/footer.php");
?>