<?php include("connect.php");?>
<?php
$query="SELECT c.`id_car`, c.`name`, c.`id_truck`, t.`ppk`, t.`base_price` from `client_cars` c 
INNER JOIN `trucks` t ON c.`id_truck`=t.`id_truck`";
$result=mysqli_query($link,$query);
?>	
<section class="box-content">
	<div class="container">
		<div class="title">Рассчитайте стоимость</div>
		<form action="success.php" method="GET">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<select name="cars" id="cars" class="caption input" onchange="showOptions(this)" style="background-color: #ffffff;"required>
						<option selected value="">Выберите ваше авто</option>
						<?php 
						while ($row=mysqli_fetch_array($result)){ ?>
							<option name="car" id="<?php echo $row[2]?>" value="<?php echo $row[3]?>" class="input caption"><?php echo $row[1]?></option>
							<?php
						} ?>
					</select>
					<div class="caption">Расстояние: <span id="distance"></span></div> 
					<div class="caption">Стоимость: <span id="summa"></span></div>
				</div>
				<div class="col-sm-12 col-md-6">
					<input type="text" class="input caption" placeholder="имя" pattern="[А-Яа-яЁё]{3,255}" name="name" style="background-color: #ffffff;" required><br>
					<input type="text" class="input caption" placeholder="телефон" id="phone" name="tel" style="background-color: #ffffff;" required><br>
				</div>
			</div>
			<input type="hidden" id="distance-to-db" name="distance-to-db" value="0">
			<input type="hidden" id="summa-to-db" name="summa-to-db" value="0">
			<input type="hidden" id="car_id-to-db" name="car_id-to-db" value="0">
			<input type="hidden" id="start" name="start" value="0">
			<input type="hidden" id="finish" name="finish" value="0">
			<?php
			$result=mysqli_query($link,$query);
			while ($row=mysqli_fetch_array($result)) {?>
				<input type="hidden" id="car<?php echo $row[2]?>" value="<?php echo $row[4]?>">
			<?php }
			?>
			<div id="map" style="width: 100%; height: 400px"></div>
			<input type="hidden" name="long">
			<input type="submit" value="заказать" class="button caption">
		</form>
	</div>
</section>



