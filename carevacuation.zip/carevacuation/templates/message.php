<?php include("connect.php");?>
<?php
$query="SELECT `e_mail` FROM `information` WHERE 1";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result); 
//прием короткого заказа
if (isset($_GET['short'])){
	mysqli_query($link,"
		INSERT INTO `requests` (`id_request`, `date`, `client_name`, `number`, `client_car`, `distance`, `cost`, `status`) 
		VALUES (NULL, NOW(), '{$_GET['name']}', '{$_GET['tel']}', '{$_GET['cars']}', NULL, NULL, 'обрабатывается')");
}
//прием заказа с калькулятором
if (isset($_GET['long'])){
	mysqli_query($link,
		"INSERT INTO `requests` (`id_request`, `date`, `client_name`, `number`, `client_car`, `start`, `finish`, `distance`, `cost`, `status`)
		 VALUES (NULL, NOW(), '{$_GET['name']}', '{$_GET['tel']}', '{$_GET['car_id-to-db']}','{$_GET['start']}','{$_GET['finish']}','{$_GET['distance-to-db']}', '{$_GET['summa-to-db']}', 'обрабатывается')");
}
//отправка письма на почту
if(isset($_GET['name'])){
	$to=$row['e_mail'];
  	$subject = "Новый заказ!";
  	$message = "На сайт поступил новый заказ. Имя - {$_GET['name']}, номер - '{$_GET['tel']}'. Ознакомьтесь подробней с заказом в личном кабинете администратора";
  	mail ($to, $subject, $message);
}

?>
<section class="box-content">
	<div class="container">
		<div class="title">ваша заявка принята на обработку!</div>
		<div class="caption center">мы перезвоним вам в течение 5 минут, дождитесь звонка менеджера</div>
	</div>
</section>
