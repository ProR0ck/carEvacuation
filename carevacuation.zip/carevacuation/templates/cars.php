<?php include("connect.php");?>
<?php 
	$query="SELECT `name`,`capacity`,`platform_length`,`width`,`base_price`,`image` FROM `trucks`";
	$result=mysqli_query($link,$query);
?>
	<section class="box-content">
		<div class="container">
			<div class="title">Наша спецтехника</div>
			<div class="row">
				<?php 
					while ($row=mysqli_fetch_array($result)) { ?>
						<div class="col-sm-6 col-md-4 center car-box">
							<div class="center car-name"><?php echo $row[0]?></div>
							<img src="templates/images/cars/<?php echo $row[5]?>" alt="эвакуатор" class="img-fluid">
							<div class="center">Грузоподъемность - <?php echo $row[1]?> т.</div>
							<div class="center">длина платформы - <?php echo $row[2]?> м.</div>
							<div class="center">ширина - <?php echo $row[3]?> м.</div>
							<div class="center">от <?php echo $row[4]?> р.</div>
						</div>						
				<?php } ?>
			</div>
		</div>
	</section>