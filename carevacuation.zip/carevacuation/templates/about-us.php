<?php include("templates/connect.php");?>
<?php
$query="SELECT `director`,`about` FROM `information` WHERE 1";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
?>
<section class="box-content">
		<div class="container">
			<div class="title">О НАС</div>
			<div class="row">
				<div class="col-sm-12 col-md-8"> 
					<div class="text">
						<?php echo $row['about']?>
					</div>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="center">
						<img src="templates/images/руководитель.jpg" alt="директор" width="250">
						<div class="center">Генеральный директор<br><?php echo $row['director']?></div>
					</div>
				</div>
			</div>
		</div>
	</section>