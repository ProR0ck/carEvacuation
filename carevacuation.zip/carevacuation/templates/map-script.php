<script type="text/javascript">
    function showOptions(s) {
  //alert(s[s.selectedIndex].value); // get value
  //alert(s[s.selectedIndex].id); // get id
  car_id= s[s.selectedIndex].id;
  return car_id;
}


ymaps.ready(init);
var myMap, 
myPlacemark;
function init(){ 
 myMap = new ymaps.Map ("map", {
    center: [55.76, 37.64],
    zoom: 10,
    controls: ['routePanelControl']
});
		// Получение ссылки на панель.
		var control = myMap.controls.get('routePanelControl');

		// Получение мультимаршрута.
		var multiRoutePromise = control.routePanel.getRouteAsync();

		multiRoutePromise.then(function(multiRoute) {
    	// Подписка на событие обновления мультимаршрута.
    	multiRoute.model.events.add('requestsuccess', function() {
        // Получение ссылки на активный маршрут.
        var activeRoute = multiRoute.getActiveRoute();
        // Когда панель добавляется на карту, она
        // создает маршрут с изначально пустой геометрией. 
        // Только когда пользователь выберет начальную и конечную точки,
        // маршрут будет перестроен с непустой геометрией.
        // Поэтому для избежания ошибки нужно добавить проверку,
        // что маршрут не пустой.
        
        if (activeRoute) {
            var wayPoints = multiRoute.getWayPoints();
            var start = wayPoints.get(1).properties.get('name');
            var finish = wayPoints.get(0).properties.get('name');
            var car_id=showOptions(cars);
            car_id_to_db=car_id;
            car_id="car"+car_id;
            var cost = document.getElementById(car_id).value;
            cost=parseInt(cost,10);
            var index=document.getElementById("cars").value;
            // Вывод информации об активном маршруте.
            //console.log("Длина: " + activeRoute.properties.get("distance").text);
            //console.log("Время прохождения: " + activeRoute.properties.get("duration").text);
            routeLength = activeRoute.properties.get("distance");
            routeValue = routeLength.value / 1000;
            tarif=document.getElementById("cost").value;
            sum=(Math.floor(routeValue) * index) + cost;
            Lenth=routeLength.text.replace(/\s+/g,'');
            Lenth=Lenth.replace('км','');
            distance.innerHTML = routeLength.text;
            summa.innerHTML =sum+"₽ (вызов техники  "+cost+"₽ + "+ (Math.floor(routeValue) * index)+ "₽ за "+ routeLength.text+")";
            document.getElementById("distance-to-db").value=Lenth;
            document.getElementById("summa-to-db").value=sum;
            document.getElementById("car_id-to-db").value=car_id_to_db;
            document.getElementById("start").value=start;
            document.getElementById("finish").value=finish;

        }
    });
    }, function (err) {
       console.log(err); 
   });   

    }
</script>