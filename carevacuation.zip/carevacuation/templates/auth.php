<?php include("connect.php");?>

<?php 
	$query=mysqli_query($link,"SELECT `login`, `password` FROM `users`");
	while($row=mysqli_fetch_array($query)){
		if (($_POST['log']==$row[0]) && ($_POST['pas']==$row[1])){ ?>
			<script type="text/javascript">
				location.replace("admin/index.php");
			</script>
		<?php }
	}
?>

<section class="box-content" style="height: 60%;">
	<div class="title">
		неверный логин или пароль!<br>
		повторите попытку авторизации
	</div>
</section>