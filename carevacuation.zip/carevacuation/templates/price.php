<?php include("connect.php");?>
<?php
$query="SELECT c.`name`, c.`weight`, t.`ppk`, t.`base_price` from `client_cars` c
INNER JOIN `trucks` t ON  c.`id_truck`=t.`id_truck`";
$result=mysqli_query($link,$query);
?>

<section class="box-content">
	<div class="container">
		<div class="table-responsive">
			<div class="title">Цены на услуги эвакуатора</div>
			<table class="table table-sm table-bordered middle">
				<thead>
					<tr>
						<td>Тип ТС</td>
						<td>Вес (тонн)</td>
						<td>Цена за километр</td>
						<td>Цена заказа</td>
					</tr>
				</thead>
				<tbody>
					<?php
					while($row=mysqli_fetch_array($result)){?>
						<tr>
							<td><?php echo $row[0];?></td>
							<td><?php echo $row[1];?></td>
							<td><?php echo $row[2];?>,00 руб.</td>
							<td><?php echo $row[3];?>,00 руб.</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</section>