	<?php include("connect.php");?>
	<?php
	$query="SELECT `id_car`, `name` from `client_cars`";
	$result=mysqli_query($link,$query);
	$query2="SELECT `phone` FROM `information` WHERE 1";
	$result2=mysqli_query($link,$query2);
	$row2=mysqli_fetch_array($result2);
	?>	
	<section class="box-content">
		<div class="container">
			 <div class="row">
				<div class="col-sm-12 col-md-6 center">
					<div class="form align-middle">
						<form action="success.php" method="GET">
							<div class="caption">вызвать эвакуатор</div>
							<input type="text" class="input caption" placeholder="имя" name="name" pattern="[А-Яа-яЁё]{3,255}" required> <br>
							<input type="text" class="input caption" placeholder="телефон" name="tel" id="phone"required><br>
							<select name="cars" class="caption input" required>
								<option selected value="">ваше авто</option>
								<?php 
								while ($row=mysqli_fetch_array($result)){ ?>
									<option name="car" id="<?php echo $row[0]?>" value="<?php echo $row[0]?>" class="input caption"><?php echo $row[1]?></option>
									<?php
								} ?>
							</select>
							<br>
							<input type="hidden" name="short">
							<input type="submit" class="button caption" value="отправить">
						</form>
					</div>
				</div>
				<div class="col-sm-12 col-md-6 center">
					<div class="help">
						<div class="title-help"> нужна помощь? </div>
						<div class="caption"><i class="fa fa-phone" aria-hidden="true"></i> Позвоните нам: 
							<br><a href="tel:<?php echo $row2['phone']?>"><?php echo $row2['phone']?></a>
							<br><img src="templates/images/evacuator.png" alt="эвакуатор" class="img-fluid">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>