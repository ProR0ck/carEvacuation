<?php 
	$host="localhost";
	$user="root";
	$password="root";
	$db_name="evacuation";
	$link=mysqli_connect($host,$user,$password,$db_name);
?>