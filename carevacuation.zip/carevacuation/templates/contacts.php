<?php include("templates/connect.php");?>
<?php
$query="SELECT `adres`, `phone`, `e_mail`, `time` FROM `information` WHERE 1";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
?>
	<section class="box-content">
		<div class="container">
			<div class="title">наши контакты</div>
			<div class="row center">
				<div class="col-sm-12 col-md-6">
					<div class="caption"><i class="fa fa-map-marker" aria-hidden="true"></i> АДРЕС:</div>
					<div> <?php echo $row['adres']?> </div>
					<br>
					<div class="caption"><i class="fa fa-clock-o" aria-hidden="true"></i> ВРЕМЯ РАБОТЫ:</div>
					<div><?php echo $row['time']?></div>
				</div>
				<div class="col-sm-12 col-md-6">
					<div class="caption"><i class="fa fa-phone" aria-hidden="true"></i> телефон</div>
					<div><a href="tel:<?php echo $row['phone']?>"><?php echo $row['phone']?></a></div>
					<br>
					<div class="caption"><i class="fa fa-envelope" aria-hidden="true"></i> E-mail</div>
					<div><a href="mailto:<?php echo $row['e_mail']?>"><?php echo $row['e_mail']?></a></div>
				</div>
			</div>
		</div>
	</section>