	<section class="box-content">
		<div class="container">
			<div class="title"> почему мы? </div>
			<div class="row">
				<div class="col-sm-6 col-md-3 center">
					<img src="templates/images/кошелек.png" alt="кошелек" class="img">
					<br> Низкие цены
				</div>
				<div class="col-sm-6 col-md-3 center">
					<img src="templates/images/эвакуатор.png" alt="" class="img">
					<br> Быстрая эвакуация
				</div>
				<div class="col-sm-6 col-md-3 center">
					<img src="templates/images/гарантия.png" alt="" class="img">
					<br> Гарантия на услугу
				</div>
				<div class="col-sm-6 col-md-3 center">
					<img src="templates/images/гео.png" alt="" class="img">
					<br> Москва и МО
				</div>
			</div>
		</div>
	</section>