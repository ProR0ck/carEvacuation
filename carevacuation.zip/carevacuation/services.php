<?php
	include("templates/header.php");
	include("templates/advantages.php");
	include("templates/cars.php");
	include("templates/price.php");
	include("templates/feedback.php");
	include("templates/footer.php");
?>