-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 08, 2020 at 03:39 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `evacuation`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_cars`
--

CREATE TABLE `client_cars` (
  `id_car` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `id_truck` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client_cars`
--

INSERT INTO `client_cars` (`id_car`, `name`, `weight`, `id_truck`) VALUES
(1, 'Мотоцикл', 0.5, 1),
(2, 'Легковой автомобиль', 2, 1),
(3, 'Внедорожник', 3.5, 2),
(4, 'Газель', 3.5, 3),
(5, 'Микроавтобус', 3.8, 4),
(6, 'Автобус', 7.5, 5),
(7, 'Грузовик', 10, 6);

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `id` int(11) NOT NULL,
  `adres` varchar(512) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `e_mail` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `director` varchar(255) DEFAULT NULL,
  `about` varchar(2048) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `vk` varchar(255) DEFAULT NULL,
  `telegram` varchar(255) DEFAULT NULL,
  `whasapp` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`id`, `adres`, `phone`, `e_mail`, `time`, `director`, `about`, `instagram`, `vk`, `telegram`, `whasapp`) VALUES
(1, 'Москва, Варшавское шоссе 33,Бизнес Центр Виарт', '+7 (495) 555 55 55', 'evgeny.kuptsoff@yandex.ru', 'ПН-ВС: круглосуточно', 'Купцов Евгений Владимирович', 'Наш сервис по подбору эвакуаторов в Москве и Московской области - гарантия быстрой эвакуации автомобиля вне зависимости от времени суток. Более 7 лет нашими усилиями водители, столкнувшиеся с неприятностью в пути, получают качественные услуги эвакуатора круглосуточно, в любой день недели.', 'https://www.instagram.com/eugen1147/', 'https://vk.com/eugengang', 'https://tlgg.ru/@kazbekis', 'https://wa.me/79234567890');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id_request` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `client_car` int(11) DEFAULT NULL,
  `start` varchar(255) DEFAULT NULL,
  `finish` varchar(255) DEFAULT NULL,
  `distance` double DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id_request`, `date`, `client_name`, `number`, `client_car`, `start`, `finish`, `distance`, `cost`, `status`) VALUES
(29, '2020-05-08 06:30:45', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(30, '2020-05-08 06:30:47', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(31, '2020-05-08 06:30:48', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(32, '2020-05-08 06:30:49', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(33, '2020-05-08 06:30:49', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(34, '2020-05-08 06:30:50', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(35, '2020-05-08 06:30:51', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(36, '2020-05-08 06:30:51', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(37, '2020-05-08 06:30:52', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(38, '2020-05-08 06:30:53', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(39, '2020-05-08 06:30:59', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(40, '2020-05-08 06:31:00', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(41, '2020-05-08 06:31:02', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(42, '2020-05-08 06:31:02', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(43, '2020-05-08 06:31:05', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(44, '2020-05-08 06:31:07', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(45, '2020-05-08 06:31:09', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(46, '2020-05-08 06:31:10', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(47, '2020-05-08 06:31:12', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается'),
(48, '2020-05-08 06:31:14', 'иванов иван иванович', '8 (111) 111-11-11', 1, 'улица Расковой, 26/29с2', 'проспект Мира, 211к2', 13, 2100, 'обрабатывается');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status`) VALUES
('завершено'),
('на исполнении'),
('обрабатывается'),
('приостановлено');

-- --------------------------------------------------------

--
-- Table structure for table `trucks`
--

CREATE TABLE `trucks` (
  `id_truck` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `capacity` double DEFAULT NULL,
  `platform_length` double DEFAULT NULL,
  `width` double DEFAULT NULL,
  `base_price` double DEFAULT NULL,
  `ppk` double DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trucks`
--

INSERT INTO `trucks` (`id_truck`, `name`, `capacity`, `platform_length`, `width`, `base_price`, `ppk`, `image`) VALUES
(1, 'Эвакуатор с лебедкой', 2, 5.8, 2.2, 1500, 50, 'auto-001.png'),
(2, 'Эвакуатор с платформой', 5, 6.8, 2.4, 1900, 50, 'auto-002.png'),
(3, 'Эвакуатор с манипулятором', 6.16, 5.7, 2.5, 3500, 50, 'auto-003.png'),
(4, 'Двухэтажный эвакуатор', 4.5, 5.2, 2.4, 2500, 50, 'auto-004.png'),
(5, 'Частичная погрузка', 10, 13, 2.5, 5000, 80, 'auto-005.png'),
(6, 'Низкорамный тралл', 33, 15, 2.9, 10000, 100, 'auto-006.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `login`, `password`) VALUES
(1, 'admin', '12345'),
(2, 'manager', '12345'),
(3, 'kupcov', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_cars`
--
ALTER TABLE `client_cars`
  ADD PRIMARY KEY (`id_car`),
  ADD KEY `client_cars_ibfk_1` (`id_truck`);

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id_request`),
  ADD KEY `requests_ibfk_1` (`client_car`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status`);

--
-- Indexes for table `trucks`
--
ALTER TABLE `trucks`
  ADD PRIMARY KEY (`id_truck`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_cars`
--
ALTER TABLE `client_cars`
  MODIFY `id_car` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id_request` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `trucks`
--
ALTER TABLE `trucks`
  MODIFY `id_truck` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `client_cars`
--
ALTER TABLE `client_cars`
  ADD CONSTRAINT `client_cars_ibfk_1` FOREIGN KEY (`id_truck`) REFERENCES `trucks` (`id_truck`) ON UPDATE SET NULL;

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`client_car`) REFERENCES `client_cars` (`id_car`) ON UPDATE SET NULL,
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`status`) REFERENCES `status` (`status`) ON UPDATE SET NULL;
