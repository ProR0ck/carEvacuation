<?php
	include("templates/header.php");
	include("templates/message.php");
	include("templates/contacts.php");
	include("templates/footer.php");
?>