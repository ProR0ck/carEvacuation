<?php include("../templates/connect.php");?>
<?php
$query="SELECT * FROM `trucks` WHERE `id_truck`='{$_GET['id_edit']}'";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
?>
<section class="box-content">
	<div class="container">
		<div class="title">изменение характеристик</div>
		<form action="trucks.php">
			<div class="row">
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Название</div>
					<input type="text" class="input-edit" name="name" placeholder="название" 
					value="<?php echo $row['name']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Грузоподъемность (тонн)</div>
					<input type="text" class="input-edit" name="capacity" placeholder="Грузоподъемность" 
					value="<?php echo $row['capacity']?>" required >
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Длина платформы (метры)</div>
					<input type="text" class="input-edit" name="platform_length" placeholder="длина платформы" 
					value="<?php echo $row['platform_length']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Ширина (метры)</div>
					<input type="text" class="input-edit" name="width" placeholder="ширина" 
					value="<?php echo $row['width']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Стоимость вызова (руб.)</div>
					<input type="text" class="input-edit" name="base_price" placeholder="стоимость вызова" 
					value="<?php echo $row['base_price']?>" required pattern="[1-9]{1,10}">
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">цена за 1 км (руб.)</div>
					<input type="text" class="input-edit" name="ppk" placeholder="цена за 1 км" 
					value="<?php echo $row['ppk']?>" required pattern="[1-9]{1,10}"> \d+(,\d{2})?
				</div>
			</div>
			<input type="hidden" name="id_edit_complete" value="<?php echo $_GET['id_edit']?>">
			<input type="submit" value="изменить" class="button caption" name="edit_complete">
		</form>
	</div>
</div>
</section>