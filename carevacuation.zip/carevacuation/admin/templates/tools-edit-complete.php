<?php include("../templates/connect.php");?>
<?php
	$query="
	UPDATE 
		`information` 
	SET 
		`adres`=		'{$_GET['adres']}',
		`phone`=		'{$_GET['phone']}',
		`e_mail`=		'{$_GET['e_mail']}',
		`time`=			'{$_GET['time']}',
		`director`=		'{$_GET['director']}',
		`about`=		'{$_GET['about']}',
		`instagram`=	'{$_GET['instagram']}',
		`vk`=			'{$_GET['vk']}',
		`telegram`=		'{$_GET['telegram']}',
		`whasapp`=		'{$_GET['whasapp']}' 
	WHERE 1";
	mysqli_query($link,$query);
?>
<script type="text/javascript">
	location.replace("tools.php");
</script>