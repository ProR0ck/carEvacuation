<?php include("../templates/connect.php");?>
<?php
	$query="DELETE FROM `requests` WHERE `id_request`='{$_GET['id_delete']}'";
	mysqli_query($link,$query);
?>

<script type="text/javascript">
	location.replace("orders.php");
</script>