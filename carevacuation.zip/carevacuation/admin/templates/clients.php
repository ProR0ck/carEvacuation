<?php include("../templates/connect.php");?>
<?php
$query="
SELECT c.`id_car`, c.`name`, c.`weight`, c.`id_truck`, t.`name` 
FROM `client_cars` c
LEFT JOIN `trucks` t ON c.`id_truck`=t.`id_truck`";
$result=mysqli_query($link,$query);
?>
<section class="box-content">
	<div class="container">
		<div class="title">авто клиентов</div>
		<div class="row">
			<?php while ($row=mysqli_fetch_array($result)) { ?>
				<div class="col-sm-12 col-md-4 center car-box" style="border: solid 1px">
					<div class="center car-name"><?php echo $row[1]?></div>
					<div class="center">
						Вес - <?php echo $row[2]?> т.
					</div>
					<div class="center">
						Спецтехника для эвакуации: <br>
						<a href="trucks.php?id_edit=<?php echo $row['id_truck']?>"> <?php echo $row[4]?></a>
					</div>
					<div class="center">
						<a href="clients.php?id_edit=<?php echo $row['id_car'] ?>">
							<i class="fa fa-pencil-square-o" aria-hidden="true"></i> изменить
						</a> <br>
						<a href="clients.php?id_delete=<?php echo $row['id_car'] ?>"
							onClick="return window.confirm('вы точно хотите удалить?');"
							style="color: red;">
							<i class="fa fa-trash" aria-hidden="true"></i> удалить
						</a>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
</section>