<?php include("../templates/connect.php");?>
<?php
$query="SELECT `director`, `instagram`, `vk`, `telegram`, `whasapp`,`e_mail` FROM `information` WHERE 1";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
?>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<div class="text">
						© МАДК им. А.А. Николаева 2020 г.
						<br>Разработчик: студент группы 48/11П
						<br><?php echo $row['director']?>
						<a 	target="_blank" class="footer-links" 
							href="mailto:<?php echo $row['`e_mail`']?>">
							<br><i class="fa fa-envelope" aria-hidden="true"></i> evgeny.kuptsoff@yandex.ru
						</a>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="text">
						<a 	target="_blank" class="footer-links" 
							href="<?php echo $row['instagram']?>">
							<i class="fa fa-instagram" aria-hidden="true"></i> instagram
						</a>
						<a 	target="_blank" class="footer-links" 
							href="<?php echo $row['vk']?>">
							<br><i class="fa fa-vk" aria-hidden="true"></i> Вконтакте
						</a>
						<a 	target="_blank" class="footer-links" 
							href="<?php echo $row['telegram']?>">
							<br><i class="fa fa-telegram" aria-hidden="true"></i> Telegram
						</a>
						<a 	target="_blank" class="footer-links" 
							href="<?php echo $row['whasapp']?>">
							<br><i class="fa fa-whatsapp" aria-hidden="true"></i> WhatsApp
						</a>
					</div>
				</div>
			</div>
		</div>
	</footer>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.2.1/dist/jquery.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery.maskedinput@1.4.1/src/jquery.maskedinput.min.js" type="text/javascript"></script>
<script>
      $(document).ready(function() {
        $("#phone").mask("+7 (999) 999-99-99");
      });
 </script>