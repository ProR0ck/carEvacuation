<?php include("../templates/connect.php");?>
<?php
$query="
UPDATE `requests` 
SET 
	`client_name`=	'{$_GET['client_name']}',
	`number`=		'{$_GET['number']}',
	`client_car`=	'{$_GET['client_car']}',
	`start`=		'{$_GET['start']}',
	`finish`=		'{$_GET['finish']}',
	`distance`=		'{$_GET['distance']}',
	`cost`=			'{$_GET['cost']}',
	`status`=		'{$_GET['status']}' 

WHERE `id_request`='{$_GET['id_edit_complete']}'";
mysqli_query($link,$query);
?>
<script type="text/javascript">
	location.replace("orders.php");
</script>