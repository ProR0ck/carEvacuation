<?php include("../templates/connect.php");?>
<?php
$query="
UPDATE 
	`client_cars` 
SET 
	`name`=		'{$_GET['name']}',
	`weight`=	'{$_GET['weight']}',
	`id_truck`=	'{$_GET['truck-name']}' 
WHERE 
	`id_car`='{$_GET['id_edit_complete']}'";
	
mysqli_query($link,$query);
?>
<script type="text/javascript">
	location.replace("clients.php");
</script>