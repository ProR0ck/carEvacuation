<?php include("../templates/connect.php");?>
<?php
$query="
DELETE FROM 
		`client_cars` 
	WHERE 
		`id_truck`='{$_GET['id_delete']}'";

mysqli_query($link,$query);
?>
<script type="text/javascript">
	location.replace("clients.php");
</script>