<?php include("../templates/connect.php");?>
<?php 
	$query="SELECT * FROM `trucks` WHERE 1";
	$result=mysqli_query($link,$query);
?>
	<section class="box-content">
		<div class="container">
			<div class="title">спецтехника</div>
			<div class="row">
				<?php 
					while ($row=mysqli_fetch_array($result)) { ?>
						<div class="col-sm-12 col-md-4 center car-box" style="border: solid 1px">
							<div class="center car-name"><?php echo $row['name']?></div>
							<img src="../templates/images/cars/<?php echo $row['image']?>" alt="эвакуатор" class="img-fluid">
							<div class="center">
								Грузоподъемность - <?php echo $row['capacity']?> т.
							</div>
							<div class="center">
								длина платформы - <?php echo $row['platform_length']?> м.
							</div>
							<div class="center">
								ширина - <?php echo $row['width']?> м.
							</div>
							<div class="center">
								от <?php echo $row['base_price']?>,00 руб.
							</div>
							<div class="center">
								цена за 1 км - <?php echo $row['ppk']?>,00 руб.
							</div>
							<a href="trucks.php?id_edit=<?php echo $row['id_truck'] ?>">
								<i class="fa fa-pencil-square-o" aria-hidden="true"></i> изменить
							</a> <br>
							<a href="trucks.php?id_delete=<?php echo $row['id_truck'] ?>"
								onClick="return window.confirm('вы точно хотите удалить?');"
								style="color: red;">
								<i class="fa fa-trash" aria-hidden="true"></i> удалить
							</a>
						</div>						
				<?php } ?>
			</div>
		</div>
	</section>