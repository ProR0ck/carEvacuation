<section class="box-content">
	<div class="container">
		<div class="title">меню панели администратора</div>
		<div class="row justify-content-center center">
			<div class="col-6">
				<div class="options">
					<a href="orders.php" class="option-links" style="text-decoration: none;">
						<div class="caption">ЗАКАЗЫ</div>
						<div class="options-icon">
							<i class="fa fa-list-alt" aria-hidden="true"></i>
						</div>
					</a>
				</div>
			</div>
			<div class="col-6">
				<div class="options">
					<a href="trucks.php" class="option-links" style="text-decoration: none;">
						<div class="caption">ЭВАКУАТОРЫ</div>
						<div class="options-icon">
							<i class="fa fa-truck" aria-hidden="true"></i>
						</div>
					</a>

				</div>
			</div>
			<div class="col-6">
				<div class="options">
					<a href="clients.php" class="option-links" style="text-decoration: none;">
						<div class="caption">АВТО</div>
						<div class="options-icon">
							<i class="fa fa-car" aria-hidden="true"></i>
						</div>
					</a>

				</div>
			</div>
			<div class="col-6">
				<div class="options">
					<a href="tools.php" class="option-links" style="text-decoration: none;">
						<div class="caption">НАСТРОЙКИ</div>
						<div class="options-icon">
							<i class="fa fa-cog" aria-hidden="true"></i>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>