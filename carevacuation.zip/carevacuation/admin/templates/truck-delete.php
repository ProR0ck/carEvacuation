<?php include("../templates/connect.php");?>
<?php
$query="
DELETE FROM 
		`trucks` 
	WHERE 
		`id_truck`='{$_GET['id_delete']}'";

mysqli_query($link,$query);;
?>
<script type="text/javascript">
	location.replace("trucks.php");
</script>