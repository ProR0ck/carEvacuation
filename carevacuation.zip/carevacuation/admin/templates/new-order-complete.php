<?php include("../templates/connect.php");?>
<?php

$d= date("Y-m-d H:i:s");
$query="
INSERT INTO `requests`(
	`id_request`,
	`date`, 
	`client_name`, 
	`number`, 
	`client_car`, 
	`start`, 
	`finish`, 
	`distance`, 
	`cost`, 
	`status`) 
VALUES (
	NULL,
	'{$d}',
	'{$_GET['client_name']}', 
	'{$_GET['number']}', 
	'{$_GET['client_car']}',
	'{$_GET['start']}', 
	'{$_GET['finish']}', 
	'{$_GET['distance']}', 
	'{$_GET['cost']}', 
	'{$_GET['status']}')";

mysqli_query($link,$query);
?>

<script type="text/javascript">
	location.replace("orders.php");
</script>

