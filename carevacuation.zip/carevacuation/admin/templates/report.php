<?php include("../templates/connect.php");?>
<?php 
$summ=0;
$distance=0;
$query="
SELECT r.`id_request`, r.`date`, r.`client_name`, r.`number`, c.`name`, r.`start`, r.`finish`, r.`distance`, t.`name`, r.`cost`, r.`status`
FROM `requests` r
LEFT JOIN `client_cars` c ON r.`client_car` = c.`id_car`
LEFT JOIN `trucks` t ON t.`id_truck` = c.`id_truck` 
ORDER BY r.`date`";
$result=(mysqli_query($link,$query));
$i=1;
?>
<section class="box-content">
	<div class="container">
		<div class="title">Финансовый отчет фирмы Car Evacuation</div>
		<div class="table-responsive">
			<table class="table-sm table-bordered middle" style="font-size: 14px;">
				<thead class="center">
					<tr>
						<td>№</td>
						<td>дата</td>
						<td>клиент</td>
						<td>расстояние</td>
						<td>эвакуатор</td>
						<td>цена</td>
					</tr>
				</thead>
				<tbody>
					<?php
					while($row=mysqli_fetch_array($result)){ ?>
						<tr>
							<td><?php echo $i++;?></td> 
							<td><?php echo date('d.m.Y', strtotime($row[1]))?></td>
							<td><?php echo $row[2]?></td>
							<td><?php echo $row[7]; if($row[7]!='') echo " км.";?></td>
							<td><?php echo $row[8]?></td>
							<td><?php echo $row[9]; if($row[7]!='') echo ",00 руб.";?></td>
						</tr>
					<?php 
						$summ=$summ+$row[9];
						$distance=$distance+$row[7];
						}
					?>
					<tr>
						<td></td>
						<td></td>
						<td style="text-align: right;"><b>Итого</b></td>
						<td><b><?php echo $distance?> км.</b></td>
						<td style="text-align: right;"><b>Итого</b></td>
						<td><b><?php echo $summ?>,00 руб.</b></td>
					</tr>
				</tbody>
			</table>
			<br>
			<div class="row" s>
				<div class="col-sm-12" style="font-size: 14px; text-align: right;">Генеральный директор "CarEvacuation" Купцов Е.В. <br>дата <?php echo date('d.m.Y')?> <img src="../templates/images/печатькупца.png" alt="" style="width: 150px;">
				</div>	
			</div>
		</div>
	</div>
</section>