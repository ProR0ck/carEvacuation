<?php include("../templates/connect.php");?>
<?php
$query="SELECT `id`, `adres`, `phone`, `e_mail`, `time`, `director`, `about`,`instagram`, `vk`, `telegram`, `whasapp` FROM `information` WHERE 1";
$result=mysqli_query($link,$query);
$row=mysqli_fetch_array($result);
?>
<section class="box-content">
	<div class="container">
		<div class="title">информация на сайте</div>
		<form action="tools.php">
			<div class="row">
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-map-marker" aria-hidden="true"></i> Адрес</div>
					<input type="text" class="input-edit" name="adres" placeholder="Введите" 
					value="<?php echo $row['adres']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-phone"  aria-hidden="true"></i> Телефон</div>
					<input type="text" class="input-edit" name="phone" id="phone" placeholder="Введите" 
					value="<?php echo $row['phone']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-envelope" aria-hidden="true"></i> E-mail</div>
					<input type="text" class="input-edit" name="e_mail" placeholder="Введите" 
					value="<?php echo $row['e_mail']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-clock-o" aria-hidden="true"></i> Время работы</div>
					<input type="text" class="input-edit" name="time" placeholder="Введите" 
					value="<?php echo $row['time']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-user-circle-o" aria-hidden="true"></i> Директор</div>
					<input type="text" class="input-edit" name="director" placeholder="Введите" 
					value="<?php echo $row['director']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-instagram" aria-hidden="true"></i> instagram</div>
					<input type="text" class="input-edit" name="instagram" placeholder="Введите" 
					value="<?php echo $row['instagram']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-vk" aria-hidden="true"></i> VK</div>
					<input type="text" class="input-edit" name="vk" placeholder="Введите" 
					value="<?php echo $row['vk']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-telegram" aria-hidden="true"></i> Telegram</div>
					<input type="text" class="input-edit" name="telegram" placeholder="Введите" 
					value="<?php echo $row['telegram']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input"><i class="fa fa-whatsapp" aria-hidden="true"></i> Whasapp</div>
					<input type="text" class="input-edit" name="whasapp" placeholder="Введите" 
					value="<?php echo $row['whasapp']?>" required>
				</div>
				<div class="col-sm-12 col-md-12">
					<div class="caption-input">Статья о нас</div>
					<textarea required class="about-us" name="about"><?php echo $row['about']?></textarea>
				</div>
			</div>
			<input type="submit" value="изменить" class="button caption" name="edit_complete">
		</form>
	</div>
</div>
</section>