<?php include("../templates/connect.php");?>
<?php
	$query="
	UPDATE `trucks` 
	SET 
		`name`=				'{$_GET['name']}',
		`capacity`=			'{$_GET['capacity']}',
		`platform_length`=	'{$_GET['platform_length']}',
		`width`=			'{$_GET['width']}',
		`base_price`=		'{$_GET['base_price']}',
		`ppk`=				'{$_GET['ppk']}'
	WHERE 
		`id_truck`= 		'{$_GET['id_edit_complete']}'";
	mysqli_query($link,$query);
?>
<script type="text/javascript">
	location.replace("trucks.php");
</script>