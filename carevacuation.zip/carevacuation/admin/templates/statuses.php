<?php include("../templates/connect.php");?>
<?php 
$summ=0;
$distance=0;
$query="SELECT * FROM `status`";
$result=(mysqli_query($link,$query));
$i=1;
?>
<section class="box-content">
	<div class="container">
		<div class="title">Справочник статусов</div>
		<a href="#" class="btn btn-primary ptop">
			<i class="fa fa-plus" aria-hidden="true"></i> Добавить новый статус
		</a><br><br> 
		<div class="table-responsive">
			<table class="table-sm table-bordered middle>
				<thead class="center">
					<tr>
						<td>№</td>
						<td>Статус</td>
						<td>изменть</td>
						<td>удалить</td>
					</tr>
				</thead>
				<tbody>
					<?php
					while($row=mysqli_fetch_array($result)){ ?>
						<tr>
							<td><?php echo $i++;?></td> 
							<td><?php echo $row[0]?></td>
							<td>
								<a href="#">
									<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
								</a>
							</td>
							<td>
								<a style="color: red;" 
									href="#" 
									onClick="return window.confirm('вы точно хотите удалить статус?');">
									<i class="fa fa-trash" aria-hidden="true"></i>
								</a>
							</td>
						</tr>
					<?php 
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
</section>