<?php include("../templates/connect.php");?>
<?php
$query1="
SELECT c.`id_car`, c.`name`, c.`weight`, c.`id_truck`, t.`name` 
FROM `client_cars` c
LEFT JOIN `trucks` t ON c.`id_truck`=t.`id_truck`";
$result1=mysqli_query($link,$query1);
$row1=mysqli_fetch_array($result1);
//список эвакуаторов
$query2="SELECT `id_truck`,`name` FROM `trucks`";
$result2=mysqli_query($link,$query2);
?>
<section class="box-content">
	<div class="container">
		<div class="title">изменение характеристик</div>
		<form action="clients.php">
			<div class="row">
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Название</div>
					<input type="text" class="input-edit" name="name" placeholder="название авто" 
					value="<?php echo $row1[1]?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Вес (тонн)</div>
					<input type="text" class="input-edit" name="weight" placeholder="вес" 
					value="<?php echo $row1['weight']?>" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Спецтехника для эвакуации:</div>
					<select name="truck-name" class="input-edit" required>
						<option selected value="<?php echo $row1['id_truck']?>"><?php echo $row1[4]?></option>
						<?php 
						while ($row2=mysqli_fetch_array($result2)){ ?>
							<option name="truck_option" value="<?php echo $row2['id_truck']?>" class="input caption"><?php echo $row2['name']?></option>
							<?php
						} ?>
					</select>
				</div>
			</div>
			<input type="hidden" name="id_edit_complete" value="<?php echo $_GET['id_edit']?>">
			<input type="submit" value="изменить" class="button caption" name="edit_complete">
		</form>
	</div>
</section>