<?php include("../templates/connect.php");?>
<?php 
$query="
SELECT r.`id_request`, r.`date`, r.`client_name`, r.`number`, c.`name`, r.`start`, r.`finish`, r.`distance`, t.`name`, r.`cost`, r.`status`
FROM `requests` r
LEFT JOIN `client_cars` c ON r.`client_car` = c.`id_car`
LEFT JOIN `trucks` t ON t.`id_truck` = c.`id_truck` 
ORDER BY r.`date` DESC";
$result=(mysqli_query($link,$query));
$i=1;
?>
<section class="box-content">
	<div class="container-full">
		<div class="title">Заказы на эвакуацию</div>
		<a href="orders.php?new-order" class="btn btn-primary ptop">
			<i class="fa fa-plus" aria-hidden="true"></i> Добавить новый заказ
		</a> 
		<button type="button" class="btn btn-info ptop" onclick="location.href = 'orders.php?report'">
			финансовый отчет на весь период
		</button>
		<button type="button" class="btn btn-info ptop" onclick="location.href = 'orders.php?status'">
			Справочник статусов
		</button>
		<br><br>
		<div class="table-responsive">
			<table class="table-sm table-bordered middle" style="font-size: 14px;">
				<thead class="center">
					<tr>
						<td>№</td>
						<td>дата</td>
						<td>клиент</td>
						<td>телефон</td>
						<td>авто клиента</td>
						<td>откуда</td>
						<td>куда</td>
						<td>расстояние</td>
						<td>эвакуатор</td>
						<td>цена</td>
						<td>статус</td>
						<td></td>
						<td></td>
					</tr>
				</thead>
				<tbody>
					<?php
					while($row=mysqli_fetch_array($result)){ ?>
						<tr>
							<td><?php echo $i++;?></td> 
							<td><?php echo date('d.m.Y', strtotime($row[1]))?></td>
							<td><?php echo $row[2]?></td>
							<td><?php echo $row[3]?></td>
							<td><?php echo $row[4]?></td>
							<td><?php echo $row[5]?></td>
							<td><?php echo $row[6]?></td>
							<td><?php echo $row[7]; if($row[7]!='') echo " км.";?></td>
							<td><?php echo $row[8]?></td>
							<td><?php echo $row[9]; if($row[7]!='') echo ",00 руб.";?></td>
							<td><?php echo $row[10]?></td>
							<td>
								<a href="orders.php?id_edit=<?php echo $row[0]?>">
									<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
								</a>
							</td>
							<td>
								<a style="color: red;" 
									href="orders.php?id_delete=<?php echo $row[0]?>" 
									onClick="return window.confirm('вы точно хотите удалить заказ?');">
									<i class="fa fa-trash" aria-hidden="true"></i>
								</a>
							</td>
						</tr>
					<?php }
					?>
				</tbody>
			</table>
		</div>
	</div>
</section>