<?php include("../templates/connect.php");?>
<?php
$query1="
SELECT r.`id_request`, r.`date`, r.`client_name`, r.`number`, r.`client_car`, c.`name`, r.`start`, r.`finish`, r.`distance`, r.`cost`, r.`status`
FROM `requests` r
LEFT JOIN `client_cars` c ON r.`client_car` = c.`id_car`
WHERE `id_request`='{$_GET['id_edit']}'";
$result1=mysqli_query($link,$query1);
$row1=mysqli_fetch_array($result1);
//машины клиентов
$query2="SELECT `id_car`, `name` from `client_cars`";
$result2=mysqli_query($link,$query2);
//статусы
$query3="SELECT * FROM `status` WHERE 1";
$result3=mysqli_query($link,$query3);
?>
<section class="box-content">
	<div class="container">
		<form action="orders.php">
			<div class="title">редактирование заявки</div>
			<div class="row">
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Клиент</div>
					<input type="text" class="input-edit" name="client_name" value="<?php echo $row1['client_name']?>"rplaceholder="введите ФИО" 
						pattern="[А-Яа-яЁё]{3,255}" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Телефон</div>
					<input type="text" class="input-edit" name="number" value="<?php echo $row1['number']?>"required placeholder="+7 (999) 99 99 999" id="phone">
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Тип авто клиента</div>
					<select name="client_car" class="input-edit" required>
						<option selected value="<?php echo $row1['client_car']?>"><?php echo $row1['name']?></option>
						<?php 
						while ($row2=mysqli_fetch_array($result2)){ ?>
							<option name="client_car_option" value="<?php echo $row2[0]?>" class="input caption"><?php echo $row2[1]?></option>
							<?php
						} ?>
					</select>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Откуда</div>
					<input type="text" class="input-edit" name="start" value="<?php echo $row1['start']?>" placeholder="введите адрес" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Куда</div>
					<input type="text" class="input-edit" name="finish" value="<?php echo $row1['finish']?>" placeholder="введите адрес" required>
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Расстояние (км.)</div>
					<input type="text" class="input-edit" name="distance" value="<?php echo $row1['distance']?>" required placeholder="введите адрес" 
					pattern="[1-9]{1,10}">
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Стоимость (руб.)</div>
					<input type="text" class="input-edit" name="cost" value="<?php echo $row1['cost']?>" required placeholder="введите стоимость" 
					pattern="[1-9]{1,10}">
				</div>
				<div class="col-sm-12 col-md-4">
					<div class="caption-input">Статус</div>
					<select name="status" class="input-edit" required>
						<option selected value="<?php echo $row1['status']?>"><?php echo $row1['status']?></option>
						<?php 
						while ($row3=mysqli_fetch_array($result3)){ ?>
							<option name="status_option" value="<?php echo $row3['status']?>" class="input caption"><?php echo $row3['status']?></option>
							<?php
						} ?>
					</select>
				</div>
			</div>
			<input type="hidden" name="id_edit_complete" value="<?php echo $_GET['id_edit']?>">
			<input type="submit" value="изменить" class="button caption" name="edit_complete">
		</form>
	</div>
</section>
