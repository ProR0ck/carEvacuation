<head>
	<title>панель администратора</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="../templates/style/style.css">
	<link rel="stylesheet" type="text/css" href="../templates/bootstrap-4.3.1-dist/css/bootstrap.min.css">
	<script src="../templates/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../templates/font-awesome-4.7.0/css/font-awesome.css">
	<script src="https://api-maps.yandex.ru/2.1/?apikey=0a42cf15-1486-406a-8651-a2da3108a394&amp;lang=ru_RU" type="text/javascript"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<meta charset="utf-8">
</head>
<header>
	<div class="container">

		<nav  class="navbar navbar-expand-lg navbar-light">
			<a class="navbar-brand" href="index.php" style="color: #fff;">CarEvacuation</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="orders.php" onclick="window.print();" style="color: #fff;">ЭКСПОРТ В PDF И ПЕЧАТЬ</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="../index.php" style="color: #fff;"><i class="fa fa-sign-out" aria-hidden="true"></i> ВЫХОД</a>
					</li>
				</ul>
			</div>
		</nav>

		<script>
			$('.dropdown-toggle').click(function(e) {
				if ($(document).width() > 768) {
					e.preventDefault();
					var url = $(this).attr('href'); 
					if (url !== '#') { 
						window.location.href = url;
					}
				}
			});
		</script>
	</div>
</header>