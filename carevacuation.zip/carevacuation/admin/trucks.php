<?php
	include("templates/header.php");
	if ((!isset($_GET['id_edit'])) && (!isset($_GET['id_delete'])) && (!isset($_GET['edit_complete'])))		
		include("templates/trucks.php");

	if (isset($_GET['id_edit']))
		include("templates/truck-edit.php");

	if (isset($_GET['id_delete']))
		include("templates/truck-delete.php");

	if (isset($_GET['edit_complete']))
		include("templates/truck-edit-complete.php");
	
	include("templates/footer.php");
?>