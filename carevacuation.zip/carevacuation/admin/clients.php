<?php
	include("templates/header.php");

	if ((!isset($_GET['id_edit'])) && (!isset($_GET['id_edit_complete'])) && ((!isset($_GET['id_delete']))))
		include("templates/clients.php");
	
	if (isset($_GET['id_edit']))
		include("templates/car-edit.php");

	if (isset($_GET['id_edit_complete']))
		include("templates/car-edit-complete.php");

	if (isset($_GET['id_delete']))
		include("templates/car-delete.php");

	include("templates/footer.php");
?>