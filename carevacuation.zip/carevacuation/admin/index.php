<?php
	include("templates/header.php");
	include("templates/panel.php");
	include("templates/footer.php");
?>