<?php
	include("templates/header.php");

	if (!isset($_GET['edit_complete']))
		include("templates/tools.php");
	if (isset($_GET['edit_complete']))
		include("templates/tools-edit-complete.php");
	include("templates/footer.php");
?>