<?php
	if(!isset($_GET['report'])) include("templates/header.php");
	
	if (
		(!isset($_GET['id_edit'])) && 
		(!isset($_GET['edit_complete'])) && 
		(!isset($_GET['id_delete'])) && 
		(!isset($_GET['new-order'])) && 
		(!isset($_GET['new-order-complete'])) &&
		(!isset($_GET['report'])) &&
		(!isset($_GET['status']))
		)include("templates/orders.php");
	
	if (isset($_GET['id_edit']))
		include("templates/edit-order.php");
	
	if (isset($_GET['edit_complete']))
		include("templates/edit-order-complete.php");

	if (isset($_GET['id_delete']))
		include("templates/delete-order.php");

	if (isset($_GET['new-order']))
		include("templates/new-order.php");

	if (isset($_GET['new-order-complete']))
		include("templates/new-order-complete.php");

	if (isset($_GET['report'])){
		include("templates/header-print.php");
		include("templates/report.php");
	}
	if (isset($_GET['status'])){
		include("templates/statuses.php");
	}

	if(!isset($_GET['report']))include("templates/footer.php");
?>
