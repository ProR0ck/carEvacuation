<meta charset="utf-8">
<script src="https://api-maps.yandex.ru/2.1/?apikey=0a42cf15-1486-406a-8651-a2da3108a394&amp;lang=ru_RU" type="text/javascript"></script>

<div id="map" style="width:450px;height:300px"></div>

<script type="text/javascript">
ymaps.ready(function () {
    var myMap = new ymaps.Map('map', {
        center: [55.753994, 37.622093],
        zoom: 9,
        controls: []
    });
    
    // Построим мультимаршрут.
    var multiRoute = new ymaps.multiRouter.MultiRoute({
        referencePoints: [
            'Москва, ул. Льва Толстого 16',
            'Москва, метро Третьяковская'
        ]
    });
    // Отобразим мультимаршрут на карте.
    myMap.geoObjects.add(multiRoute);
    multiRoute.model.events.add('requestsuccess', function() {
        // Коллекция путевых точек маршрута.
        
        // Проход по коллекции путевых точек.
        // Для каждой точки зададим содержимое меток.
    }); 
    // Добавление маршрута на карту.
    myMap.geoObjects.add(multiRoute); 
    var wayPoints = multiRoute.getWayPoints();
    console.log(wayPoints);   
});  
</script>